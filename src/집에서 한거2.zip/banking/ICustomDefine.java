package banking;

public interface ICustomDefine {
	//메뉴선택
	int Make = 1, Deposit = 2, Withdraw = 3, Inquire = 4, Saving = 5, Exit = 6;

	//신용등급
	int A = 7, B = 4, C = 2;
}
