package banking;

public class MenuSelectException extends Exception{
	public MenuSelectException() {
		super("잘못입력했습니다.");
	}
}
